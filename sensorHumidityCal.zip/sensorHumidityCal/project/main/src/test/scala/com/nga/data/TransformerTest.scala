package com.nga.data

import org.apache.spark.sql.functions._
import org.scalatest.funsuite.AnyFunSuite
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.DataFrame
import com.holdenkarau.spark.testing.DataFrameSuiteBase
import com.nga.data.transformer.TransformerData.getTheMaxMinAvgValues

import java.io.File

class TransformerTest extends AnyFunSuite with DataFrameSuiteBase {

  // Initialize SparkSession
  lazy val spark: SparkSession = SparkSession.builder()
    .appName("SensorDataProcessorTest")
    .master("local[*]") // Use local mode for testing
    .getOrCreate()

  // Import implicits for DataFrame operations

  import spark.implicits._

  // Test case for getTheMaxMinAvgValues function
  test("getTheMaxMinAvgValues should return correct min, max, and avg values") {
    // Sample input data
    val inputData = Seq(
      ("s1", 10.0), ("s1", 20.0), ("s1", 30.0),
      ("s2", 15.0), ("s2", 25.0), ("s2", 35.0)
    ).toDF("sensor_id", "humidity")

    // Expected output data
    val expectedData = Seq(
      ("s1", 10.0), ("s1", 20.0), ("s1", 30.0),
      ("s2", 15.0), ("s2", 25.0), ("s2", 35.0)
    ).toDF("sensor_id", "min", "max", "avg")

    // Call the function to be tested
    val result = getTheMaxMinAvgValues(inputData)

    // Assert the result matches the expected output
    assertDataFrameEquals(expectedData, result)
  }

    test("getNumOfProcessFiles should return the number of files in the directory") {
      val directoryPath = "C:\\Users\\91997\\IdeaProjects\\sensorHumidityCal\\project\\main\\resources"

      // Create some dummy files in the directory
      val dummyFiles = List("file1.txt", "file2.txt", "file3.txt")
      dummyFiles.foreach { fileName =>
        val file = new File(directoryPath, fileName)
        file.createNewFile()
      }

      // Call the function to be tested
      val result = FileProcessor.getNumOfProcessFiles(directoryPath)

      // Assert the result matches the expected number of files
      assert(result == dummyFiles.length)

      // Clean up: delete the dummy files
      dummyFiles.foreach { fileName =>
        val file = new File(directoryPath, fileName)
        file.delete()
      }
    }
}