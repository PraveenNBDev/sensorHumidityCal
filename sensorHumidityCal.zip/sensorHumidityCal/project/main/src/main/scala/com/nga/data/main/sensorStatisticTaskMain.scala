package com.nga.data

import com.nga.data.main.readCsvFiles
import com.nga.data.transformer.TransformerData.{getNumOfFailedMeasurements, getNumOfProcessFiles, getNumOfProcessMeasurements, getTheMaxMinAvgValues}

import java.util.logging.{Level, Logger}

object sensorStatisticTaskMain {

  def main(args: Array[String]): Unit = {
    Logger.getLogger("ord").setLevel(Level.OFF)

    val spark = SparkSession.builder().master("local").config("spark.sql.warehouse.dir", "file///C://Personalized//").getOrCreate()

    // we can parameterize inputpath
    //val arg = args(0)

    val inputDir = "C:\\Users\\91997\\IdeaProjects\\sensorHumidityCal\\project\\main\\resources\\*"

    val readCsvFile = readCsvFiles.readCsvFileData(inputDir)(spark)
    println("Calculate for each sensor min/avg/max of humidity")
    getTheMaxMinAvgValues(readCsvFile)
    println("Number of files processed: " + getNumOfProcessFiles(inputDir))
    println("Number of processed Measurements: " + getNumOfProcessMeasurements(readCsvFile).count())
    println("Number of failed processed Measurements: " + getNumOfFailedMeasurements(readCsvFile).count())
  }
}
