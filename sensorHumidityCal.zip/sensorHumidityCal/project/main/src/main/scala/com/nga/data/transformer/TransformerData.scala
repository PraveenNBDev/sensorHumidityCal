package com.nga.data.transformer

import java.io.File

object TransformerData {

  def getTheMaxMinAvgValues(df: DataFrame): DataFrame = {
    val df1 = df.groupBy("sensor_id")
      .agg(min("humidity").as("min"), max("humidity").as("max"), avg("humidity").as("avg"))

    println("STDOUT")
    df1.show(false)

    df1
  }

  def getNumOfProcessFiles(file: String): Int = {
    var listOfFiles: List[File] = null
    val d = new File(file)
    if (d.exists && d.isDirectory){
      listOfFiles = d.listFiles.filter(_.isFile).toList
    }else {
      List[File]()
    }

    listOfFiles.size
  }

  def getNumOfProcessMeasurements(df: DataFrame): DataFrame = df.where(!col("humidity").isin("NaN"))

  def getNumOfFailedMeasurements(df: DataFrame): DataFrame = df.where(col("humidity").isin("NaN"))

}
