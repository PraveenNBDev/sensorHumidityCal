package com.nga.data.main

object readCsvFiles {

  def readCsvFileData(inputPath: String)(implicit spark: SparkSession): DataFrame = {

    val schema = StructType(Array(
      StructFiled("sensor_id", StringType, null),
        StructFiled("humidity", StringType, null)
    ))

    spark.read.format("csv").option("header", true).schema(schema).csv(inputPath)

  }


}
